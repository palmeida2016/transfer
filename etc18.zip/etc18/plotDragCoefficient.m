%% Header
% Script to read forces.dat file from a simulation and plot drag
% coefficient as a function of time.

%% Clear workspace
clc; clear; close all;

%% Define constants
global rho u A d;
rho = 998; % Water Density
u = 1.25; % Mean Flow Velocity
d = 0.04; % Cylinder diameter
A = 0.2 * d; % Frontal Area


movAvgN = 100; % Moving Average of Last N values

%% Define files to read
files = { %'~/Research/conferences/etc18/meshRefinementValidation/baseline.dat';
%     '~/Research/conferences/etc18/meshRefinementValidation/baseline_comparison.dat';
%     '~/Research/conferences/etc18/meshRefinementValidation/baseline_halfX_halfY.dat';
%     '~/Research/conferences/etc18/meshRefinementValidation/baseline_nas.dat';
%     '~/Research/conferences/etc18/meshRefinementValidation/U2.dat';
%     '~/Research/conferences/etc18/meshRefinementValidation/U1.6.dat';
%     '~/Research/conferences/etc18/meshRefinementValidation/perfect_cylinder.dat';
%     '~/Research/conferences/etc18/meshRefinementValidation/farfield_refinement.dat';
%     '~/Research/conferences/etc18/meshRefinementValidation/wall_refine.dat';
%     '~/Research/conferences/etc18/meshRefinementValidation/wall_push.dat';
%     '~/Research/conferences/etc18/meshRefinementValidation/wall_push1.dat';
%     '~/Research/conferences/etc18/meshRefinementValidation/forces.dat';
%     '~/Research/conferences/ffs/rotating_re50000_empty/w50.dat';
%       '~/Research/conferences/forces_U2/cylinder.dat';
      '~/Research/conferences/forces_U2/baseline.dat';
      '~/Research/conferences/forces_U2/forward_actuators1_6.dat';
      '~/Research/conferences/forces_U2/forward_actuators2.dat';
      '~/Research/conferences/forces_U2/forward_actuators2_4.dat';


};

headers = { %'Baseline',
%     'Cylinder with Static Actuators',
    %'Baseline Half X Half Y',
%     'Baseline Nas',
%     'Cylinder with Forward Actuators $v_t=2$',
%     'Cylinder with Forward Actuators $v_t=1.6$',
%     'Perfect Cylinder',
%     'Farfield Refinement',
%     'Wall Refinement',
%     'Wall Push',
%     'Wall Push',
%     'New Test',
%     'w50',
%        'Cylinder'
       'Cylinder with Static Actuators',
       'Cylinder with Forward Actuators $v_t=1.6$',
       'Cylinder with Forward Actuators $v_t=2$',
       'Cylinder with Forward Actuators $v_t=2.4$',
};

%% Read and Plot files
% Define colors for plots
colors = [57 106 177;
    204 37 41;
    83 81 84;
    62 150 81;
    255 0 0]./255;

% Plot
hold on;
for i = 1:length(files)
    [time, force] = readData(files{i});
    cd = calculateCd(force);
    cd_mov_average = sum(cd(end-(movAvgN-1):end)) / movAvgN;
    fprintf('Average Cd = %2.4f for case: %s\n', cd_mov_average, headers{i});
    plot(time, cd,"DisplayName",headers{i}, 'Color',colors(i,:));
%     yline(cd_mov_average, '--', 'HandleVisibility','off');
end
hold off;

ylim([1 2]);

%% Plot Settings

set(gca,'FontSize',15, 'FontName', 'Arial', 'LineWidth',3,'GridLineStyle','-','MinorGridLineStyle','-')
set( findobj(gca,'type','line'), 'LineWidth', 3);
set(gcf,'units','inches');
set(gcf,'position',[0 0 10 8])
set(gcf, 'PaperUnits', 'inches', 'PaperPosition',[0 0 10 8])
legend('Interpreter','latex','FontSize',22);
xlabel('$tU_\infty/D$ ','Interpreter','latex',"FontSize",24);
ylabel('$C_d$', 'Interpreter', 'latex',"FontSize",24);
title('Drag Coefficient $C_D$', 'Interpreter', 'latex',"FontSize",24);

%% Helper Functions
function [time,force_v] = readData(name)
    data = readtable(name);

    % Read Time
    time = data{:,1};

    % Non-Dimensionalize Time
    global u d;
    time = time ./ (d/u);

    % Read Pressure Forces
    force_p = data{:,3};
    force_p = split(force_p, ' ');
    force_p = force_p(:,1);
    force_p = erase(force_p, ")");
    force_p = str2double(force_p);

    % Read Viscous Forces
    force_v = data{:,3};
    force_v = split(force_v, ' ');
    force_v = force_v(:,1);
    force_v = str2double(force_v);

    force = force_p + force_v;
end

function cd = calculateCd(force)
    global rho u A;

    cd = 2 * force / (rho * u^2 * A);
end